Citations for data in this repository or joined into this repository during pipeline execution:

 - [DESA, World Population Prospects 2022 (2022). https://population.un.org/wpp/Download.
]
 - [R. Geyer, J. R. Jambeck, K. L. Law, Production, use, and fate of all plastics ever made. Sci. Adv. 3, e1700782 (2017).](https://www.science.org/doi/10.1126/sciadv.1700782)
 - C. Liu, S. Hu, R. Geyer. Manuscript in Process (2024).
 - [OECD, Real GDP long-term forecast (2023).](https://doi.org/10.1787/d927bc18-en)

Data may be requested from these authors or found at the links above. Data may be downloaded by automated scripts and combined with files in this directory.